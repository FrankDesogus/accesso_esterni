import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../providers/visit_providers.dart';
import '../../../../core/routing/app_router.dart';
import '../../../../shared/widgets/kiosk_scaffold.dart';
import '../../../../core/config/app_config.dart';

enum _HomeMode { none, checkin }

class SelectionOption {
  final String value; // ✅ VALUE reale della selection (es: Carta_Identità)
  final String label; // ✅ testo mostrato in UI (es: Carta d'Identità)
  const SelectionOption({required this.value, required this.label});
}

class VisitCheckInPage extends ConsumerStatefulWidget {
  const VisitCheckInPage({Key? key}) : super(key: key);

  @override
  ConsumerState<VisitCheckInPage> createState() => _VisitCheckInPageState();
}

class _VisitCheckInPageState extends ConsumerState<VisitCheckInPage> {
  _HomeMode _mode = _HomeMode.none;

  final _formKey = GlobalKey<FormState>();

  final _firstNameController = TextEditingController();
  final _lastNameController = TextEditingController();
  final _reasonController = TextEditingController();
  final _companyController = TextEditingController();
  final _docNumberController = TextEditingController();

  // ✅ DOC TYPES
  List<SelectionOption> _docTypeOptions = const [];
  bool _loadingDocTypes = false;
  String? _docTypesError;

  // ✅ Selected VALUE da inviare a Odoo
  String? _docTypeValue;

  // ✅ HOSTS
  List<_HostOption> _hosts = const [];
  bool _loadingHosts = false;
  String? _hostsError;

  int? _selectedHostId;
  String? _selectedHostName;

  String? _hostsDomainDebug;

  // ⚠️ Campi reali (dal tuo flow)
  static const String _modelVisitor = 'x_visitatori';
  static const String _fieldVisitor = 'x_studio_tipo_di_documento';

  static const String _modelVisit = 'x_visite_esterne';
  static const String _fieldVisit = 'x_studio_tipo_di_documento_visita';

  @override
  void initState() {
    super.initState();
    debugPrint('[VisitCheckInPage] initState CALLED');

    Future.microtask(() async {
      await _loadDocTypeOptions(); // carico selection aggiornata dopo modifica in Studio
      await _loadHosts();
    });
  }

  @override
  void dispose() {
    _firstNameController.dispose();
    _lastNameController.dispose();
    _reasonController.dispose();
    _companyController.dispose();
    _docNumberController.dispose();
    super.dispose();
  }

  // ---------------------------
  // DEBUG HELPERS
  // ---------------------------
  String _hexCodepoints(String s) =>
      s.runes.map((r) => 'U+${r.toRadixString(16).toUpperCase().padLeft(4, '0')}').join(' ');

  void _logOption(SelectionOption o, String tag) {
    debugPrint('$tag value="${o.value}" label="${o.label}"');
    debugPrint('$tag value cps: ${_hexCodepoints(o.value)}');
    debugPrint('$tag label cps: ${_hexCodepoints(o.label)}');
  }

  void _resetFormUi() {
    _firstNameController.clear();
    _lastNameController.clear();
    _reasonController.clear();
    _companyController.clear();
    _docNumberController.clear();

    _docTypeValue = null;

    _selectedHostId = null;
    _selectedHostName = null;
  }

  Future<List<SelectionOption>> _loadSelectionViaFieldsGet({
    required String model,
    required String fieldName,
  }) async {
    final odoo = ref.read(odooClientProvider);

    debugPrint('[DOC_TYPES] fields_get START model=$model field=$fieldName');

    final fields = await odoo
        .fieldsGet(
      model: model,
      fieldNames: [fieldName],
      attributes: const ['selection', 'type', 'string', 'required', 'readonly'],
    )
        .timeout(const Duration(seconds: 15));

    final fieldInfo = fields[fieldName];
    if (fieldInfo is! Map) {
      throw Exception('fields_get: fieldInfo non valido per $model.$fieldName');
    }

    debugPrint('[DOC_TYPES] $model.$fieldName type=${fieldInfo['type']} string="${fieldInfo['string']}"');

    final selection = fieldInfo['selection'];
    if (selection is! List) {
      throw Exception('fields_get: selection non valida per $model.$fieldName (got ${selection.runtimeType})');
    }

    debugPrint('[DOC_TYPES] $model.$fieldName selection RAW len=${selection.length}');
    for (var i = 0; i < selection.length && i < 30; i++) {
      debugPrint('[DOC_TYPES] $model.$fieldName selection[$i]=${selection[i]}');
    }

    final options = <SelectionOption>[];
    for (final item in selection) {
      if (item is List && item.length >= 2) {
        final value = item[0]?.toString().trim() ?? '';
        final label = item[1]?.toString().trim() ?? '';
        if (value.isEmpty || label.isEmpty) continue;
        options.add(SelectionOption(value: value, label: label));
      }
    }

    options.sort((a, b) => a.label.toLowerCase().compareTo(b.label.toLowerCase()));

    debugPrint('[DOC_TYPES] $model.$fieldName parsed count=${options.length}');
    for (var i = 0; i < options.length && i < 5; i++) {
      _logOption(options[i], '[DOC_TYPES][SAMPLE][$model.$fieldName][$i]');
    }

    debugPrint('[DOC_TYPES] fields_get END model=$model field=$fieldName');
    return options;
  }

  Future<void> _loadDocTypeOptions() async {
    debugPrint('[DOC_TYPES] ===== LOAD START =====');

    setState(() {
      _loadingDocTypes = true;
      _docTypesError = null;
    });

    try {
      // ✅ carico entrambe per controllare che siano allineate
      final visitor = await _loadSelectionViaFieldsGet(model: _modelVisitor, fieldName: _fieldVisitor);
      final visit = await _loadSelectionViaFieldsGet(model: _modelVisit, fieldName: _fieldVisit);

      // confronto “soft”: set dei value
      final visitorValues = visitor.map((o) => o.value).toSet();
      final visitValues = visit.map((o) => o.value).toSet();
      final sameValues = visitorValues.length == visitValues.length && visitorValues.containsAll(visitValues);

      debugPrint('[DOC_TYPES] compare values visitor vs visit -> same=$sameValues');
      if (!sameValues) {
        debugPrint('[DOC_TYPES] WARNING: values differ. visitor=$visitorValues visit=$visitValues');
      }

      // ✅ uso la selection della VISITA come sorgente UI (ma essendo allineate è indifferente)
      final options = visit;

      final stillExists = _docTypeValue != null && options.any((o) => o.value == _docTypeValue);

      setState(() {
        _docTypeOptions = options;
        _loadingDocTypes = false;
        if (!stillExists) _docTypeValue = null;
      });

      debugPrint('[DOC_TYPES] ===== LOAD END OK ===== options=${options.length}');
    } catch (e) {
      setState(() {
        _docTypeOptions = const [];
        _loadingDocTypes = false;
        _docTypesError = e.toString();
        _docTypeValue = null;
      });

      debugPrint('[DOC_TYPES] ===== LOAD END ERROR ===== $e');
    }
  }

  // ---------------------------
  // HOSTS (tuo originale)
  // ---------------------------
  Future<void> _loadHosts() async {
    debugPrint('[HOSTS] START');

    setState(() {
      _loadingHosts = true;
      _hostsError = null;
      _hostsDomainDebug = null;
    });

    try {
      final odoo = ref.read(odooClientProvider);

      final cAll = await odoo.searchCount(model: 'hr.employee', domain: []);
      final cWithUser = await odoo.searchCount(
        model: 'hr.employee',
        domain: const [
          ['user_id', '!=', false],
        ],
      );
      debugPrint('[HOSTS] count all=$cAll withUser=$cWithUser');

      const domainStrict = [
        ['active', '=', true],
        ['user_id', '!=', false],
      ];

      var res = await odoo.searchRead(
        model: 'hr.employee',
        domain: domainStrict,
        fields: const ['id', 'name', 'user_id'],
        limit: 0,
      );

      debugPrint('[HOSTS] searchRead(strict) rows=${res.length}');

      if (res.isEmpty && cWithUser > 0) {
        const domainFallback = [
          ['user_id', '!=', false],
        ];

        debugPrint('[HOSTS] strict returned 0 but withUser=$cWithUser. Retrying WITHOUT active filter...');
        res = await odoo.searchRead(
          model: 'hr.employee',
          domain: domainFallback,
          fields: const ['id', 'name', 'user_id'],
          limit: 0,
        );

        debugPrint('[HOSTS] searchRead(fallback) rows=${res.length}');
        _hostsDomainDebug = domainFallback.toString();
      } else {
        _hostsDomainDebug = domainStrict.toString();
      }

      final hosts = <_HostOption>[];
      for (final row in res) {
        final id = row['id'];
        final name = row['name'];
        if (id is int && name is String && name.trim().isNotEmpty) {
          hosts.add(_HostOption(id: id, name: name.trim()));
        }
      }

      hosts.sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));

      final stillExists = _selectedHostId != null && hosts.any((h) => h.id == _selectedHostId);

      setState(() {
        _hosts = hosts;
        _loadingHosts = false;

        if (!stillExists) {
          _selectedHostId = null;
          _selectedHostName = null;
        }
      });

      debugPrint('[HOSTS] END OK hosts=${hosts.length} domain=$_hostsDomainDebug');
    } catch (e) {
      setState(() {
        _hosts = const [];
        _loadingHosts = false;
        _hostsError = e.toString();
      });
      debugPrint('[HOSTS] END ERROR: $e');
    }
  }

  void _setSelectedHost(_HostOption host) {
    setState(() {
      _selectedHostId = host.id;
      _selectedHostName = host.name;
    });
  }

  void _clearSelectedHost() {
    setState(() {
      _selectedHostId = null;
      _selectedHostName = null;
    });
  }

  // ---------------------------
  // SUBMIT
  // ---------------------------
  Future<void> _onSubmitCheckIn() async {
    final form = _formKey.currentState;
    if (form == null) return;
    if (!form.validate()) return;

    final controller = ref.read(visitControllerProvider.notifier);

    final opt = _docTypeOptions.firstWhere(
          (o) => o.value == _docTypeValue,
      orElse: () => const SelectionOption(value: '<NULL_OR_NOT_FOUND>', label: '<NULL_OR_NOT_FOUND>'),
    );

    debugPrint('========== [CHECKIN SUBMIT] ==========');
    debugPrint('[CHECKIN] docTypeValue="$_docTypeValue" docTypeLabel="${opt.label}"');
    debugPrint('[CHECKIN] docTypeValue cps: ${_hexCodepoints(_docTypeValue ?? '')}');
    debugPrint('[CHECKIN] hostName="$_selectedHostName"');
    debugPrint('=====================================');

    await controller.createVisit(
      firstName: _firstNameController.text.trim(),
      lastName: _lastNameController.text.trim(),
      reason: _reasonController.text.trim().isEmpty ? null : _reasonController.text.trim(),
      company: _companyController.text.trim().isEmpty ? null : _companyController.text.trim(),
      docType: _docTypeValue, // ✅ VALUE reale, ora allineato (es: Carta_Identità)
      docNumber: _docNumberController.text.trim().isEmpty ? null : _docNumberController.text.trim(),
      hostName: (_selectedHostName == null || _selectedHostName!.trim().isEmpty) ? null : _selectedHostName!.trim(),
    );
  }

  @override
  Widget build(BuildContext context) {
    ref.listen(visitControllerProvider, (previous, next) {
      if (!mounted) return;

      debugPrint(
        '[VisitCheckInPage] state changed: '
            'currentVisit=${next.currentVisit?.id}, '
            'isLoading=${next.isLoading}, '
            'error=${next.errorMessage}',
      );

      if (next.errorMessage != null && next.errorMessage != previous?.errorMessage) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(next.errorMessage!)),
        );
      }

      final prevId = previous?.currentVisit?.id;
      final nextId = next.currentVisit?.id;
      final createdNewVisit = nextId != null && nextId != prevId;

      if (_mode == _HomeMode.checkin && createdNewVisit && next.errorMessage == null) {
        debugPrint('[VisitCheckInPage] Navigo verso Privacy...');
        Navigator.of(context).pushNamed(AppRouter.privacyRoute);
      }
    });

    final state = ref.watch(visitControllerProvider);

    return KioskScaffold(
      title: 'Benvenuto',
      child: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24.0),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 650),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  'Accesso visitatori',
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.headlineMedium,
                ),
                const SizedBox(height: 20),

                Row(
                  children: [
                    Expanded(
                      child: SizedBox(
                        height: 56,
                        child: ElevatedButton(
                          onPressed: state.isLoading
                              ? null
                              : () {
                            _resetFormUi();
                            setState(() => _mode = _HomeMode.checkin);
                          },
                          child: const Text(
                            'ENTRATA',
                            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: SizedBox(
                        height: 56,
                        child: ElevatedButton(
                          onPressed: state.isLoading
                              ? null
                              : () {
                            ref.read(visitControllerProvider.notifier).reset();
                            Navigator.of(context).pushNamed(AppRouter.checkoutScanRoute);
                          },
                          child: const Text(
                            'USCITA',
                            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 24),

                if (_mode != _HomeMode.checkin)
                  Padding(
                    padding: const EdgeInsets.only(top: 12.0),
                    child: Text(
                      'Seleziona ENTRATA per registrare una nuova visita\n'
                          'oppure USCITA per registrare l’uscita tramite badge.',
                      textAlign: TextAlign.center,
                      style: Theme.of(context).textTheme.bodyLarge,
                    ),
                  ),

                if (_mode == _HomeMode.checkin) ...[

                  const SizedBox(height: 12),

                  Form(
                    key: _formKey,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        TextFormField(
                          controller: _firstNameController,
                          decoration: const InputDecoration(labelText: 'Nome *', border: OutlineInputBorder()),
                          textInputAction: TextInputAction.next,
                          validator: (value) => (value == null || value.trim().isEmpty) ? 'Inserisci il nome' : null,
                        ),
                        const SizedBox(height: 16),

                        TextFormField(
                          controller: _lastNameController,
                          decoration: const InputDecoration(labelText: 'Cognome *', border: OutlineInputBorder()),
                          textInputAction: TextInputAction.next,
                          validator: (value) =>
                          (value == null || value.trim().isEmpty) ? 'Inserisci il cognome' : null,
                        ),
                        const SizedBox(height: 16),

                        TextFormField(
                          controller: _companyController,
                          decoration: const InputDecoration(labelText: 'Società', border: OutlineInputBorder()),
                          textInputAction: TextInputAction.next,
                        ),
                        const SizedBox(height: 16),

                        // HOST
                        if (_loadingHosts) ...[
                          const Text('Carico persone da visitare...'),
                          const SizedBox(height: 8),
                          const LinearProgressIndicator(),
                          const SizedBox(height: 16),
                        ] else if (_hostsError != null) ...[
                          Text('Errore caricamento persone da visitare:\n$_hostsError',
                              style: const TextStyle(color: Colors.red)),
                          const SizedBox(height: 8),
                          ElevatedButton(onPressed: _loadHosts, child: const Text('Riprova')),
                          const SizedBox(height: 16),
                        ] else if (_hosts.isNotEmpty) ...[
                          _HostAutocompleteFormField(
                            labelText: 'Persona da visitare (solo utenti)',
                            hosts: _hosts,
                            enabled: !state.isLoading,
                            selectedHostId: _selectedHostId,
                            selectedHostName: _selectedHostName,
                            onSelected: (host) => _setSelectedHost(host),
                            onClearSelection: _clearSelectedHost,
                            onRefresh: _loadHosts,
                          ),
                          const SizedBox(height: 16),
                        ],

                        // DOC TYPES dropdown: sempre “non bloccata”
                        if (_loadingDocTypes) ...[
                          const Text('Carico tipi documento...'),
                          const SizedBox(height: 8),
                          const LinearProgressIndicator(),
                          const SizedBox(height: 16),
                        ] else if (_docTypesError != null) ...[
                          Text('Errore caricamento tipi documento:\n$_docTypesError',
                              style: const TextStyle(color: Colors.red)),
                          const SizedBox(height: 8),
                          ElevatedButton(onPressed: _loadDocTypeOptions, child: const Text('Riprova')),
                          const SizedBox(height: 16),
                        ] else if (_docTypeOptions.isEmpty) ...[
                          InputDecorator(
                            decoration: const InputDecoration(labelText: 'Tipo documento', border: OutlineInputBorder()),
                            child: Row(
                              children: [
                                const Expanded(child: Text('Nessun tipo documento disponibile')),
                                const SizedBox(width: 8),
                                ElevatedButton.icon(
                                  onPressed: _loadDocTypeOptions,
                                  icon: const Icon(Icons.refresh),
                                  label: const Text('Ricarica'),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 16),
                        ] else ...[
                          DropdownButtonFormField<String>(
                            value: _docTypeValue,
                            isExpanded: true,
                            items: _docTypeOptions
                                .map((opt) => DropdownMenuItem<String>(
                              value: opt.value,
                              child: Text(opt.label, overflow: TextOverflow.ellipsis),
                            ))
                                .toList(),
                            onChanged: state.isLoading ? null : (v) => setState(() => _docTypeValue = v),
                            decoration: const InputDecoration(labelText: 'Tipo documento', border: OutlineInputBorder()),
                          ),
                          const SizedBox(height: 16),
                        ],

                        TextFormField(
                          controller: _docNumberController,
                          decoration:
                          const InputDecoration(labelText: 'Numero documento', border: OutlineInputBorder()),
                          textInputAction: TextInputAction.next,
                        ),
                        const SizedBox(height: 16),

                        TextFormField(
                          controller: _reasonController,
                          decoration: const InputDecoration(
                            labelText: 'Motivo della visita (opzionale)',
                            border: OutlineInputBorder(),
                          ),
                          maxLines: 2,
                        ),
                        const SizedBox(height: 24),

                        SizedBox(
                          height: 48,
                          child: ElevatedButton(
                            onPressed: state.isLoading ? null : _onSubmitCheckIn,
                            child: state.isLoading
                                ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 2))
                                : const Text('Procedi alla privacy'),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Autocomplete “kiosk friendly” (come tuo originale)
class _HostAutocompleteFormField extends StatefulWidget {
  final String labelText;
  final List<_HostOption> hosts;
  final bool enabled;

  final int? selectedHostId;
  final String? selectedHostName;

  final ValueChanged<_HostOption> onSelected;
  final VoidCallback onClearSelection;
  final VoidCallback onRefresh;

  const _HostAutocompleteFormField({
    required this.labelText,
    required this.hosts,
    required this.enabled,
    required this.selectedHostId,
    required this.selectedHostName,
    required this.onSelected,
    required this.onClearSelection,
    required this.onRefresh,
  });

  @override
  State<_HostAutocompleteFormField> createState() => _HostAutocompleteFormFieldState();
}

class _HostAutocompleteFormFieldState extends State<_HostAutocompleteFormField> {
  String _currentText = '';

  @override
  Widget build(BuildContext context) {
    return Autocomplete<_HostOption>(
      displayStringForOption: (o) => o.name,
      optionsBuilder: (TextEditingValue value) {
        final q = value.text.trim().toLowerCase();
        if (q.isEmpty) return widget.hosts;
        return widget.hosts.where((h) => h.name.toLowerCase().contains(q));
      },
      onSelected: (opt) {
        widget.onSelected(opt);
        setState(() => _currentText = opt.name);
      },
      fieldViewBuilder: (context, textController, focusNode, onFieldSubmitted) {
        final parentName = widget.selectedHostName;
        if (parentName != null && parentName.trim().isNotEmpty && textController.text != parentName) {
          textController.text = parentName;
          _currentText = parentName;
        }

        return TextFormField(
          controller: textController,
          focusNode: focusNode,
          enabled: widget.enabled,
          decoration: InputDecoration(
            labelText: widget.labelText,
            border: const OutlineInputBorder(),
            prefixIcon: const Icon(Icons.person_search),
            helperText: widget.selectedHostId == null
                ? 'Tocca e digita per cercare, oppure scorri la lista.'
                : 'Selezionato: ${widget.selectedHostName}',
            suffixIcon: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                if ((_currentText.trim().isNotEmpty) || textController.text.trim().isNotEmpty)
                  IconButton(
                    tooltip: 'Svuota',
                    icon: const Icon(Icons.clear),
                    onPressed: widget.enabled
                        ? () {
                      textController.clear();
                      setState(() => _currentText = '');
                      widget.onClearSelection();
                      focusNode.requestFocus();
                    }
                        : null,
                  ),
                IconButton(
                  tooltip: 'Ricarica lista',
                  icon: const Icon(Icons.refresh),
                  onPressed: widget.enabled ? widget.onRefresh : null,
                ),
              ],
            ),
          ),
          onChanged: (v) {
            setState(() => _currentText = v);
            if (widget.selectedHostId != null && v.trim() != (widget.selectedHostName ?? '').trim()) {
              widget.onClearSelection();
            }
          },
        );
      },
    );
  }
}

class _HostOption {
  final int id;
  final String name;
  const _HostOption({required this.id, required this.name});
}
